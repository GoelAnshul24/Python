import os
import time
import lamp as fr

class colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    DARK_GREEN = '\033[32m'

def file_frame_generator(frame):
    file_path = 'C:/Users/yashg/Documents/Programs/Python/Project/ASCII Animation/'+frame
    try:
        with open(file_path, 'r') as file:
            for line in file:
                print(line,end="")
    except FileNotFoundError:
        print(f"The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")


def controller(frame_list):
    os.system('cls')
    i=1
    while True:
        #file_frame_generator(frame_list[i])
        # if(i%3==0):
        #     print(colors.YELLOW)
        # if(i%3==1):
        #     print(colors.GREEN)
        # if(i%3==2):
        #     print(colors.BLUE)
        print(colors.RED)
        print(frame_list[i],end="")
        time.sleep(.3)
        os.system('cls')
        i=(i+1)%len(frame_list)



controller(fr.frames)
