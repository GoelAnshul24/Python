class node:
    data=0
    next=None
    def __init__(self , data):
        self.data=data
    
    def __str__(self):
        return str(self.data)



head=None
for i in range(1,10):
    if head == None:
        head=node(1)
        continue

    temp=head
    while temp.next != None:
        temp=temp.next

    temp.next=node(i)

while head !=None:
    print(head)
    head=head.next
