import user_data_handler
import admin_handler
import user_handler

#This source code provide an interface to login and Signup based on the choice
#Two types of USERS has been defined 
#   1.Admin
#   2.Customer user
print("Enter 1 to Login")
print("Enter 2 to Sign Up")
choice=999
try :
    choice=int(input("Enter Your Choice -- "))
except ValueError:
    print("Please Enter a Number")
    exit(0)

if choice==1:
    id=user_data_handler.login()#will call login function present in "user_data_handler" , which returns ID of user if login is sucessful else return None
    if id == "admin":
        admin_handler.admin_inteface()#will call admin_interface function in "admin_handler","admin_handler" is desinged to deal with admin request
    elif id == None:
        print("Login Failed")
    else:
        user_handler.user_inteface(id)#will call user_interface function in "user_handler","user_handler" is desinged to deal with Customer request
elif choice == 2:
    user_data_handler.add_user()#It call add_user function which adds a new user to user Database
else:
    print("Invalid Choice")
